<?php
header("Location:listagem.php"); 
?>
